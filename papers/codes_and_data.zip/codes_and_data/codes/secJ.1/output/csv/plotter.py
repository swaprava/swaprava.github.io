import matplotlib.pyplot as plt
import numpy as np
import csv, os, sys

plt.rcParams['pdf.fonttype'] = 42

INPUT_FILE = sys.argv[1]

populationSize = []
noturgent = []
medium = []
urgent = []
stdNoturgent = []
stdMedium = []
stdUrgent = []
waitNoturgent = [] 
waitMedium = []
waitUrgent = []
waitStdNoturgent = []
waitStdMedium = []
waitStdUrgent = []
utilityUrgent = []
utilityMedium = []
utilityNoturgent = []
stdUtilityUrgent = []
stdUtilityMedium = []
stdUtilityNoturgent = []

with open(INPUT_FILE, 'r') as csvfile:
	reader = csv.reader(csvfile, delimiter=',')
	next(reader)
	for rows in reader:
		populationSize.append(int(rows[0]))
		noturgent.append(float(rows[1]))
		medium.append(float(rows[2]))
		urgent.append(float(rows[3]))
		stdNoturgent.append(float(rows[4]))
		stdMedium.append(float(rows[5]))
		stdUrgent.append(float(rows[6]))
		waitNoturgent.append(float(rows[7])) 
		waitMedium.append(float(rows[8]))
		waitUrgent.append(float(rows[9]))
		waitStdNoturgent.append(float(rows[10]))
		waitStdMedium.append(float(rows[11]))
		waitStdUrgent.append(float(rows[12]))
		utilityUrgent.append(float(rows[13]))
		utilityMedium.append(float(rows[14]))
		utilityNoturgent.append(float(rows[15]))
		stdUtilityUrgent.append(float(rows[16]))
		stdUtilityMedium.append(float(rows[17]))
		stdUtilityNoturgent.append(float(rows[18]))

fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True)
X = np.array(populationSize)
# ax1.set_title('Priority-Delay tradeoff')
ax1.bar(X + 0.00, noturgent,yerr=stdNoturgent, color = 'green', width = 0.25,label ='Low',capsize=1)
ax1.bar(X + 0.25, medium,yerr=stdMedium , color = 'orange', width = 0.25,label ='Medium',capsize=1)
ax1.bar(X + 0.50, urgent, yerr=stdUrgent ,color = 'dodgerblue', width = 0.25,label ='High',capsize=1)
ax1.set_ylabel('Allocated slot preference')
ax1.legend(loc ='upper left') 
ax1.grid()
ax2.bar(X + 0.00, waitNoturgent,yerr=waitStdNoturgent, color = 'palegreen', width = 0.25,label ='Low',capsize=1)
ax2.bar(X + 0.25, waitMedium,yerr=waitStdMedium, color = 'moccasin', width = 0.25,label ='Medium',capsize=1)
ax2.bar(X + 0.50, waitUrgent, yerr=waitStdUrgent, color = 'mediumturquoise', width = 0.25,label ='High',capsize=1)
ax2.set_ylabel('Delay')
ax2.grid()
ax2.legend(loc ='upper left') 

if INPUT_FILE[5] == '2':
	plt.xlabel(r'slotSize, $n$')
else:	
	plt.xlabel(r'Population, $n$')

plt.xticks(X+0.25, X)
plt.tight_layout()

plt.show()
fig.savefig("final_plot.pdf")