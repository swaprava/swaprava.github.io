import matplotlib.pyplot as plt
import numpy as np
import csv, os, sys

plt.rcParams['pdf.fonttype'] = 42

INPUT_FILE = sys.argv[1]

X = []
computationTime = []
stdComputationTime = []

with open(INPUT_FILE, 'r') as csvfile:
	reader = csv.reader(csvfile, delimiter=',')
	next(reader)
	for rows in reader:
		X.append(float(rows[0]))
		computationTime.append(float(rows[1]))
		stdComputationTime.append(float(rows[2]))

X = np.array(X)
computationTime = np.array(computationTime)
stdComputationTime = np.array(stdComputationTime)

# fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True)
# ax1.plot(X,computationTime,'-',color='green',label ='computation-Time')
# ax1.set_ylabel('comp.Time')
# ax1.grid()
# ax1.legend(loc='upper left')

# ax2.plot(X,np.log(computationTime),'-',color='green',label ='computation-Time[log-scaled]')
# ax2.set_ylabel('comp.Time(log-scaled)')
# ax2.grid()
# ax2.legend(loc='upper left')
# plt.xlabel('slotSize')
# plt.title('computationTime vs preffered slots')
# plt.show()

fig = plt.figure()
plt.semilogy(X, computationTime,'-',color='green',label ='computationTime (sec)')
plt.fill_between(X, computationTime - stdComputationTime, computationTime + stdComputationTime,color='green', alpha=0.3)
plt.xlabel('Number of slots')
plt.ylabel('Computation time (sec)')
plt.xticks(X)
# plt.title('computationTime vs no no_of_slots')
plt.grid()
plt.show()
fig.savefig(os.path.join(os.getcwd(), 'plotter.pdf'))