python3 src.py 14 28 0 0.8 1 2 3 0

rm -rf __pycache__

python3 src.py 14 32 0 0.8 1 2 3 0

rm -rf __pycache__
