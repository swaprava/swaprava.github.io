import matplotlib.pyplot as plt
import numpy as np
import csv, os, sys, re
import scipy.stats as st
from matplotlib.patches import Rectangle

plt.rcParams['pdf.fonttype'] = 42

def getConfInt(percent, array):
	return 1.96*np.std(array)/np.sqrt(len(array))
    # return st.t.interval(percent, len(array)-1, loc=np.mean(array), scale=st.sem(array))[1] - st.t.interval(percent, len(array)-1, loc=np.mean(array), scale=st.sem(array))[0]

input_file1 = sys.argv[1]

slot_cap1 = int(input_file1.split('_')[1])

waitUrgent1=[]
waitMedium1=[]
waitNoturgent1=[]

urgentClassAllocatedSlotPreference1 = []
mediumClassAllocatedSlotPreference1 = []
notUrgentClassAllocatedSlotPreference1 = []

with open(input_file1, 'r') as csvfile:
    reader = csv.reader(csvfile, delimiter=',')
    next(reader)
    for row in reader:
        if int(row[0]) == 0:
            waitUrgent1.append(float(row[1]))
            urgentClassAllocatedSlotPreference1.append(float(row[2]))
        elif int(row[0]) == 1:
            waitMedium1.append(float(row[1]))
            mediumClassAllocatedSlotPreference1.append(float(row[2]))
        else:
            waitNoturgent1.append(float(row[1]))
            notUrgentClassAllocatedSlotPreference1.append(float(row[2]))

waitNoturgent1= np.array(waitNoturgent1)
waitMedium1 = np.array(waitMedium1)
waitUrgent1 = np.array(waitUrgent1)

urgentClassAllocatedSlotPreference1 = np.array(urgentClassAllocatedSlotPreference1)
mediumClassAllocatedSlotPreference1 = np.array(mediumClassAllocatedSlotPreference1)
notUrgentClassAllocatedSlotPreference1 = np.array(notUrgentClassAllocatedSlotPreference1)

input_file2 = sys.argv[2]

slot_cap2 = int(input_file2.split('_')[1])

waitUrgent2=[]
waitMedium2=[]
waitNoturgent2=[]

urgentClassAllocatedSlotPreference2 = []
mediumClassAllocatedSlotPreference2 = []
notUrgentClassAllocatedSlotPreference2 = []

with open(input_file2, 'r') as csvfile:
    reader = csv.reader(csvfile, delimiter=',')
    next(reader)
    for row in reader:
        if int(row[0]) == 0:
            waitUrgent2.append(float(row[1]))
            urgentClassAllocatedSlotPreference2.append(float(row[2]))
        elif int(row[0]) == 1:
            waitMedium2.append(float(row[1]))
            mediumClassAllocatedSlotPreference2.append(float(row[2]))
        else:
            waitNoturgent2.append(float(row[1]))
            notUrgentClassAllocatedSlotPreference2.append(float(row[2]))

waitNoturgent2= np.array(waitNoturgent2)
waitMedium2 = np.array(waitMedium2)
waitUrgent2 = np.array(waitUrgent2) 

urgentClassAllocatedSlotPreference2 = np.array(urgentClassAllocatedSlotPreference2)
mediumClassAllocatedSlotPreference2 = np.array(mediumClassAllocatedSlotPreference2)
notUrgentClassAllocatedSlotPreference2 = np.array(notUrgentClassAllocatedSlotPreference2)

fig, (axs1, axs2) = plt.subplots(1, 2, constrained_layout=True)
x_axis = np.arange(3)

plot_allocated_slot_pref1 = np.array([np.mean(urgentClassAllocatedSlotPreference1), np.mean(mediumClassAllocatedSlotPreference1), np.mean(notUrgentClassAllocatedSlotPreference1)])
plot_allocated_slot_pref_std_dev1 = np.array([np.std(urgentClassAllocatedSlotPreference1), np.std(mediumClassAllocatedSlotPreference1), np.std(notUrgentClassAllocatedSlotPreference1)])
plot_allocated_slot_pref_conf_int1 = np.array([getConfInt(0.95, urgentClassAllocatedSlotPreference1), getConfInt(0.95, mediumClassAllocatedSlotPreference1), getConfInt(0.95, notUrgentClassAllocatedSlotPreference1)])

plot_delay1 = np.array([np.mean(waitUrgent1), np.mean(waitMedium1), np.mean(waitNoturgent1)])
plot_delay_std_dev1 = np.array([np.std(waitUrgent1), np.std(waitMedium1), np.std(waitNoturgent1)])
plot_delay_conf_int1 = np.array([getConfInt(0.95, waitUrgent1), getConfInt(0.95, waitMedium1), getConfInt(0.95, waitNoturgent1)])

plot_allocated_slot_pref2 = np.array([np.mean(urgentClassAllocatedSlotPreference2), np.mean(mediumClassAllocatedSlotPreference2), np.mean(notUrgentClassAllocatedSlotPreference2)])
plot_allocated_slot_pref_std_dev2 = np.array([np.std(urgentClassAllocatedSlotPreference2), np.std(mediumClassAllocatedSlotPreference2), np.std(notUrgentClassAllocatedSlotPreference2)])
plot_allocated_slot_pref_conf_int2 = np.array([getConfInt(0.95, urgentClassAllocatedSlotPreference2), getConfInt(0.95, mediumClassAllocatedSlotPreference2), getConfInt(0.95, notUrgentClassAllocatedSlotPreference2)])

plot_delay2 = np.array([np.mean(waitUrgent2), np.mean(waitMedium2), np.mean(waitNoturgent2)])
plot_delay_std_dev2 = np.array([np.std(waitUrgent2), np.std(waitMedium2), np.std(waitNoturgent2)])
plot_delay_conf_int2 = np.array([getConfInt(0.95, waitUrgent2), getConfInt(0.95, waitMedium2), getConfInt(0.95, waitNoturgent2)])

axs1.bar(x_axis, plot_allocated_slot_pref1, 
            yerr=plot_allocated_slot_pref_conf_int1,
            width=0.4,
            alpha=0.4,
            color='b')

axs2.bar(x_axis, plot_delay1, 
            yerr=plot_delay_conf_int1,
            width=0.4,
            alpha=0.4,
            color='g')

# axs[1, 0].bar(x_axis, plot_allocated_slot_pref2, 
#             yerr=plot_allocated_slot_pref_conf_int2,
#             width=0.4,
#             alpha=0.4,
#             color='b')

# axs[1, 1].bar(x_axis, plot_delay2, 
#             yerr=plot_delay_conf_int2,
#             width=0.4,
#             alpha=0.4,
#             color='g')

# fig.suptitle('Allocated Slot Preference and Delay vs importance')
# axs[0, 0].set_ylabel('Allocated Slot Preference')
# axs[1, 0].set_ylabel('Delay')
# axs[0, 0].grid()
# axs[1, 0].grid()
# axs[0, 1].grid()
# axs[1, 1].grid()
# Adjust parameter as per the scale by plotter1.py
# axs[0, 0].text(-0.2, 9, 'Slot Cap: 28', style='italic', fontsize=7,
#         bbox={'facecolor': 'grey', 'alpha': 0.5, 'pad': 2})
# axs[0, 1].text(1.6, 1.8, 'Slot Cap: 28', style='italic', fontsize=7,
#         bbox={'facecolor': 'grey', 'alpha': 0.5, 'pad': 2})
# axs[1, 0].text(-0.2, 9, 'Slot Cap: 32', style='italic', fontsize=7,
#         bbox={'facecolor': 'grey', 'alpha': 0.5, 'pad': 2})
# axs[1, 1].text(1.6, 1.8, 'Slot Cap: 32', style='italic', fontsize=7,
#         bbox={'facecolor': 'grey', 'alpha': 0.5, 'pad': 2})
axs1.set_ylim(0, 10)
axs2.set_ylim(0, 2.3)
# axs[0, 1].set_ylim(0, 2)
# axs[1, 1].set_ylim(0, 2)
axs1.set_yticks(np.arange(0,11,1))
axs2.set_yticks(np.arange(0,2.3,0.2))
# axs[0, 1].set_yticks(np.arange(0,2.2,0.2))
# axs[1, 1].set_yticks(np.arange(0,2.2,0.2))
axs1.set_title("Allocated Slot Preference")
axs2.set_title("Delay")
axs1.set_xticks(ticks=[0,1,2])
axs2.set_xticks(ticks=[0,1,2])
axs1.set_xticklabels(labels=[])
# axs[0, 1].set_xticklabels(labels=[])
# axs[0, 1].set_xticks(ticks=[0,1,2])
# axs[1, 1].set_xticks(ticks=[0,1,2])
axs2.set_xticklabels(labels=['High','Medium','Low'], fontsize=10)
axs1.set_xticklabels(labels=['High','Medium','Low'], fontsize=10)
# plt.tight_layout()
plt.show()

fig.savefig(os.path.join(os.getcwd(), "tmp/"+str(input_file1.split(".csv")[0])+"_"+str(input_file2.split(".csv")[0])+"_csv1.pdf"))