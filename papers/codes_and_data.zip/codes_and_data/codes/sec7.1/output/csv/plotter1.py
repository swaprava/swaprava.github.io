import matplotlib.pyplot as plt
import numpy as np
import csv, os, sys, re
import scipy.stats as st

def getConfInt(percent, array):
	return 1.96*np.std(array)/np.sqrt(len(array))
    # return st.t.interval(percent, len(array)-1, loc=np.mean(array), scale=st.sem(array))[1] - st.t.interval(percent, len(array)-1, loc=np.mean(array), scale=st.sem(array))[0]

input_file = sys.argv[1]

slot_cap = int(input_file.split('_')[1])

waitUrgent=[]
waitMedium=[]
waitNoturgent=[]

urgentClassAllocatedSlotPreference = []
mediumClassAllocatedSlotPreference = []
notUrgentClassAllocatedSlotPreference = []

with open(input_file, 'r') as csvfile:
    reader = csv.reader(csvfile, delimiter=',')
    next(reader)
    for row in reader:
        if int(row[0]) == 0:
            waitUrgent.append(float(row[1]))
            urgentClassAllocatedSlotPreference.append(float(row[2]))
        elif int(row[0]) == 1:
            waitMedium.append(float(row[1]))
            mediumClassAllocatedSlotPreference.append(float(row[2]))
        else:
            waitNoturgent.append(float(row[1]))
            notUrgentClassAllocatedSlotPreference.append(float(row[2]))

waitNoturgent= np.array(waitNoturgent)
waitMedium = np.array(waitMedium)
waitUrgent = np.array(waitUrgent) 

urgentClassAllocatedSlotPreference = np.array(urgentClassAllocatedSlotPreference)
mediumClassAllocatedSlotPreference = np.array(mediumClassAllocatedSlotPreference)
notUrgentClassAllocatedSlotPreference = np.array(notUrgentClassAllocatedSlotPreference)

fig, (ax1, ax2) = plt.subplots(1, 2, constrained_layout=True)
x_axis = np.arange(3)

plot_allocated_slot_pref = np.array([np.mean(urgentClassAllocatedSlotPreference), np.mean(mediumClassAllocatedSlotPreference), np.mean(notUrgentClassAllocatedSlotPreference)])
plot_allocated_slot_pref_std_dev = np.array([np.std(urgentClassAllocatedSlotPreference), np.std(mediumClassAllocatedSlotPreference), np.std(notUrgentClassAllocatedSlotPreference)])
plot_allocated_slot_pref_conf_int = np.array([getConfInt(0.95, urgentClassAllocatedSlotPreference), getConfInt(0.95, mediumClassAllocatedSlotPreference), getConfInt(0.95, notUrgentClassAllocatedSlotPreference)])

plot_delay = np.array([np.mean(waitUrgent), np.mean(waitMedium), np.mean(waitNoturgent)])
plot_delay_std_dev = np.array([np.std(waitUrgent), np.std(waitMedium), np.std(waitNoturgent)])
plot_delay_conf_int = np.array([getConfInt(0.95, waitUrgent), getConfInt(0.95, waitMedium), getConfInt(0.95, waitNoturgent)])

ax1.bar(x_axis, plot_allocated_slot_pref, 
            yerr=plot_allocated_slot_pref_std_dev,
            width=0.4,
            alpha=0.4,
            color='b')

ax2.bar(x_axis, plot_delay, 
            yerr=plot_delay_conf_int,
            width=0.4,
            alpha=0.4,
            color='r')

fig.suptitle('Allocated Slot Preference and Delay vs importance')
ax1.set_ylabel('Allocated Slot Preference')
ax2.set_ylabel('Delay')
ax1.grid()
ax2.grid()
ax1.set_xlabel("Importance")
ax2.set_xlabel("Importance")
ax2.set_xticks(ticks=[0,1,2])
ax1.set_xticks(ticks=[0,1,2])
ax2.set_xticklabels(labels=['Urgent','Medium','Not Urgent'], fontsize=10)
ax1.set_xticklabels(labels=['Urgent','Medium','Not Urgent'], fontsize=10)

plt.show()
# fig.savefig(os.path.join(os.getcwd(), str(input_file.split(".csv")[0])+"_1.pdf"))
