import numpy as np
from gurobipy import *
import random, re, os, time, sys, csv, logging
import multiprocessing as mp
import matplotlib.pyplot as plt
import scipy.stats as st
from data import *

plt.rcParams['pdf.fonttype'] = 42

def getConfInt(percent, array):
	return 1.96*np.std(array)/np.sqrt(len(array))
    # return st.t.interval(percent, len(array)-1, loc=np.mean(array), scale=st.sem(array))[1] - st.t.interval(percent, len(array)-1, loc=np.mean(array), scale=st.sem(array))[0]

def print_sol(model):
	for var in model.getVars():
		if(abs(var.x)>1e-6):
			print('{0}:{1}'.format(var.varName,var.x))
			
	#print('Allocation score :{0}'.format(model.objVal))
	return None

def remove_column(matrix, column):
	return [row[:column] + row[column+1:] for row in matrix]

def optimizer(urgencyList, priority_MATRIX, N_agents, LOWER_URGENCY, MID_URGENCY, HIGHER_URGENCY, nos):
		combinations,ms = multidict({
			(y,x):(delta**(priority_MATRIX[y-1][x-1]-1)) * urgencyList[y-1] for x in range(1,nos+1) for y in range(1,len(N_agents)+1)
			})
		valuation_matrix = ms.copy()

		model = Model('allocator')
		variables = model.addVars(combinations,lb=0,vtype=GRB.BINARY,name='assign')
		model.update()
		model.addConstrs((variables.sum('*',j)<= slot_cap for j in M),'slots')
		model.addConstrs((variables.sum(i,'*')<=1 for i in N_agents),'agents')
		model.setObjective(variables.prod(ms),GRB.MAXIMIZE)
		model.write('mark0.lp')
		model.optimize()

		allocation_map={}
		for var in model.getVars():
				assign = re.search(r"\[([A-Za-z,0-9_]+)\]", var.varName)
				assign = assign.group(1)
				assign = assign.split(',')
				if(abs(var.x)>1e-6):
					allocation_map[int(assign[0])]=int(assign[1])

		return valuation_matrix, allocation_map, model.objVal

'''
Command :
	python3 src.py 14 20 0 0.5 1 2 3 0
for demo:
	python3 src.py 14 20 0 0.5 1 2 3 2
'''
no_of_slots = int(sys.argv[1])
percent_bound = int(sys.argv[3])
LOWER_URGENCY = int(sys.argv[5])
MID_URGENCY = int(sys.argv[6])
HIGHER_URGENCY = int(sys.argv[7])
start_date = int(sys.argv[8])
M = list(range(1, no_of_slots+1)) # number of slots

dictionary_len=[]
populationSize = []
non_allocated=[]

waitUrgent=[]
waitMedium=[]
waitNoturgent=[]

urgentClassAllocatedSlotPreference = []
mediumClassAllocatedSlotPreference = []
notUrgentClassAllocatedSlotPreference = []

list_unallocated_agents={}
empty_days={}
delta = float(sys.argv[4])
slot_cap= int(sys.argv[2])

MAX_POPULATION = int(len(M)*slot_cap + percent_bound*len(M)*slot_cap/100) 

start = time.perf_counter()
final_pref_allocations=[[] for _ in range(len(M))]
final_allocations=[[] for _ in range(len(M))]
distribution=[]
distribution_temp = data()
for d in range(len(distribution_temp)):
	temp = []
	for t in range(0,len(distribution_temp[d]),2):
		temp.append(distribution_temp[d][t] + distribution_temp[d][t+1])
	distribution.append(temp)

days_for_allocation=[]
next_day_passing_preference=[]

if(start_date == 0):
	days_for_allocation=[i for i in range(0,len(distribution))]
else:
	# Use this to debug -- given start_date > 0
	days_for_allocation.extend(range(start_date))

logging.basicConfig(filename="log/slotCap_"+str(slot_cap)+"_days_"+str(len(days_for_allocation))+".log", level=logging.WARNING, format='%(levelname)s %(asctime)s %(message)s', datefmt='%m/%d/%Y%I:%M:%S %p', filemode='w')
logger = logging.getLogger('myLogger')

# Loop starts with k as iter. till MAX_POPULATION
# days_for_allocation=[4,5,6]
for k in days_for_allocation:
	# If for a single k its been checked we can set MAX_POPULATION = MIN_POPULATION+1 in range
	# i.e. k = MAX_POPULATION and uncomment the desried code.
	population = sum(distribution[k])
	preferred_slot_arrangement=[0 for _ in range(0,len(M))]
	slot_fillings=[0 for _ in range(0,len(M))]

	number_samples = 1
	# Denote temp. for population size vs slot iteration
	tempTimeUrgent=[]
	tempTimeMedium=[]
	tempTimeNoturgent=[]

	rows, cols = (population , len(M))

	if(population==0):
		populationSize.append(0)
		#Finding avg time from all samples:
		waitUrgent.append(0)
		waitMedium.append(0)
		waitNoturgent.append(0)
		# Allocated Slot Preference
		urgentClassAllocatedSlotPreference.append(0)
		mediumClassAllocatedSlotPreference.append(0)
		notUrgentClassAllocatedSlotPreference.append(0)
		empty_days[int(k)]=1
		continue
	################################# check for previous day unallocated #########################
	final_non_allocated_index=[]
	next_day_passing_list_agents=[]
	next_day_passing_urgency=[]

	gap=0
	if k-1 in empty_days.keys():
		gap +=1
	if k-2 in empty_days.keys():
		gap +=1
	if k-3 in empty_days.keys():
		gap +=1    
	for number, value in list_unallocated_agents.items(): 
		day,urgency = value.split('-')
		if(int(day)<= k-2-gap ):
			final_non_allocated_index.append(number)
	for key in final_non_allocated_index:
		del list_unallocated_agents[key]
	for number, value in list_unallocated_agents.items():
		day,urgency_ = value.split('-')
		final_non_allocated_index.append(number)
		# if int(urgency_)+(MID_URGENCY-LOWER_URGENCY) > HIGHER_URGENCY:
		# 	final_non_allocated_index.append(number)
		# 	continue
		# next_day_passing_list_agents.append(value)
		# next_day_passing_urgency.append(min(int(urgency_)+(MID_URGENCY-LOWER_URGENCY),HIGHER_URGENCY))
		# next_day_passing_preference.append(priority_matrix[number-1])
	list_unallocated_agents={}
	#################################################################################################

	N = list(range(1, population+1+len(next_day_passing_list_agents))) #population base : with range(1,k) with k as iterator till MAX_POPULATION

	preferences_sorted_index = np.argsort(-1*np.array(distribution[k]))
	preferences = [0 for _ in range(len(distribution[k]))]
	for i in range(len(distribution[k])):
		preferences[preferences_sorted_index[i]] = i+1

	priority_matrix = []
	for l in range(1,rows+1):
		priority_matrix.append(list(preferences))
	for l in range(0,len(next_day_passing_list_agents)):
		list_unallocated_agents[rows+1+l]=next_day_passing_list_agents[l]
		priority_matrix.append(next_day_passing_preference[l])

	for iteration in range(number_samples): # iteration for each n. Taken as sample for each n
		print("=============================================== iteration id:"+str(k)+" ==============================================")
		# FOR RANDOM URGENCY OF EACH AGENT WITH CHANGING POPULATION
		urgencylist = []

		for i in range(rows):
			urgencylist.append(random.choices(population=[LOWER_URGENCY,MID_URGENCY,HIGHER_URGENCY], weights=[0.6, 0.3, 0.1])[0])

		urgencylist.extend(next_day_passing_urgency)

		for l in range(1,rows+1):
			list_unallocated_agents[l]=(str(k+1)+"-"+str(urgencylist[l-1]))

		valuation_matrix, allocation_map, valuation_sum = optimizer(urgencylist, priority_matrix, N, LOWER_URGENCY, MID_URGENCY, HIGHER_URGENCY, len(M))

		dictionary_len.append(len(allocation_map))
		for key in allocation_map:
			slot_fillings[allocation_map[key]-1] +=  1 
			# Append the pref. of allocated slot for urgent, medium and notUrgent -- for each day. -- i.e. append this `preferences[allocation_map[index]-1]` -- given number of samples = 1 else need to append the mean and std dev. post sampling.
			if(urgencylist[key-1]==LOWER_URGENCY):
				notUrgentClassAllocatedSlotPreference.append(preferences[allocation_map[key]-1])
			if(urgencylist[key-1]==MID_URGENCY):
				mediumClassAllocatedSlotPreference.append(preferences[allocation_map[key]-1])
			if(urgencylist[key-1]==HIGHER_URGENCY):
				urgentClassAllocatedSlotPreference.append(preferences[allocation_map[key]-1])
			del list_unallocated_agents[key] 

		############################# VCG #############################
		for index in range(1,len(N)+1):
			if index in allocation_map: #there is chance agrent might not be allocated
				valuation_allocatedAgent = valuation_matrix[(index, allocation_map[index])]
			else:
				continue
			urgency_of_agent = urgencylist[index-1]

			urgencylist_without_agent = urgencylist[:]
			priority_matrix_without_agent  = priority_matrix[:]
			N_without_agent = list(range(1,len(N)))

			del priority_matrix_without_agent[index-1]
			del urgencylist_without_agent[index-1]

			valuation_matrix_without_agent, allocation_map_without_agent, valuation_sum_without_agent = optimizer(urgencylist_without_agent, priority_matrix_without_agent, N_without_agent, LOWER_URGENCY, MID_URGENCY, HIGHER_URGENCY, len(M))

			VCG = valuation_sum_without_agent - (valuation_sum - valuation_allocatedAgent)

			if(urgency_of_agent == LOWER_URGENCY):
				tempTimeNoturgent.append(VCG)
			elif(urgency_of_agent == MID_URGENCY):
				tempTimeMedium.append(VCG)
			elif(urgency_of_agent == HIGHER_URGENCY):
				tempTimeUrgent.append(VCG)

			print("##########################################################################")
			print(" VCG( agent: "+str(index)+"/"+str(len(N))+" ,day_no: "+str(k+1)+"/"+str(len(days_for_allocation))+" ,itertion: "+str(iteration+1)+"/"+str(number_samples)+" ) =  "+str(VCG))
			logger.critical("_day: "+str(k+1)+"/"+str(len(days_for_allocation))+", agent_id: "+str(index)+"/"+str(len(N))+", agent_urgency: "+str(urgency_of_agent)+", agent_allocatedSlot: "+str(allocation_map[index])+"/"+str(no_of_slots)+", agent_allocatedSlotPreference: "+str(preferences[allocation_map[index]-1])+", wait_time: "+str(VCG))
			print("##########################################################################\n\n")

		################################################################

	# fill slot matrix
	non_allocated.append(len(list_unallocated_agents))
	for i in range(len(M)):
		final_pref_allocations[i].extend([distribution[k][i]])
		final_allocations[i].extend([slot_fillings[i]])

	populationSize.append(k)
	# Extend the delay list for the month using the delay list for the day -- given number_of_sample = 1 else need to append mean and std dev.
	waitUrgent.extend(tempTimeUrgent)
	waitMedium.extend(tempTimeMedium)
	waitNoturgent.extend(tempTimeNoturgent)

end = time.perf_counter()

print("\n\nMAX_POPULATION: "+str(MAX_POPULATION))
print(f'Time Taken for computation of {population} : {end-start} second(s)')

# Graphing
waitNoturgent= np.array(waitNoturgent)
waitMedium = np.array(waitMedium)
waitUrgent = np.array(waitUrgent) 

urgentClassAllocatedSlotPreference = np.array(urgentClassAllocatedSlotPreference)
mediumClassAllocatedSlotPreference = np.array(mediumClassAllocatedSlotPreference)
notUrgentClassAllocatedSlotPreference = np.array(notUrgentClassAllocatedSlotPreference)

final_pref_allocations_mean = [np.mean(final_pref_allocations[i]) for i in range(len(M))]
final_pref_allocations_std = [np.std(final_pref_allocations[i]) for i in range(len(M))]
final_pref_allocations_conf_int = [getConfInt(0.95, final_pref_allocations[i]) for i in range(len(M))]
final_pref_allocations_mean.append(0)
final_pref_allocations_std.append(0)
final_pref_allocations_conf_int.append(0)

final_allocations_mean = [np.mean(final_allocations[i]) for i in range(len(M))]
final_allocations_std = [np.std(final_allocations[i]) for i in range(len(M))]
final_allocations_conf_int = [getConfInt(0.95, final_allocations[i]) for i in range(len(M))]
final_allocations_mean.append(0)
final_allocations_std.append(0)
final_allocations_conf_int.append(0)

non_allocated_mean = [0 for i in range(len(M))]
non_allocated_std = [0 for i in range(len(M))]
non_allocated_conf_int = [0 for i in range(len(M))]
non_allocated_mean.append(np.mean(non_allocated))
non_allocated_std.append(np.std(non_allocated))
non_allocated_conf_int.append(getConfInt(0.95, non_allocated))

fig, (ax1, ax2) = plt.subplots(1, 2, constrained_layout=True)
x_axis = np.arange(3)
x_axis2 = np.arange(7,len(M)+8)

plot_allocated_slot_pref = np.array([np.mean(urgentClassAllocatedSlotPreference), np.mean(mediumClassAllocatedSlotPreference), np.mean(notUrgentClassAllocatedSlotPreference)])
plot_allocated_slot_pref_std_dev = np.array([np.std(urgentClassAllocatedSlotPreference), np.std(mediumClassAllocatedSlotPreference), np.std(notUrgentClassAllocatedSlotPreference)])
plot_allocated_slot_pref_conf_int = np.array([getConfInt(0.95, urgentClassAllocatedSlotPreference), getConfInt(0.95, mediumClassAllocatedSlotPreference), getConfInt(0.95, notUrgentClassAllocatedSlotPreference)])

plot_delay = np.array([np.mean(waitUrgent), np.mean(waitMedium), np.mean(waitNoturgent)])
plot_delay_std_dev = np.array([np.std(waitUrgent), np.std(waitMedium), np.std(waitNoturgent)])
plot_delay_conf_int = np.array([getConfInt(0.95, waitUrgent), getConfInt(0.95, waitMedium), getConfInt(0.95, waitNoturgent)])

with open(os.path.join(os.getcwd(), "output/csv/slotCap_"+str(slot_cap)+"_days_"+str(len(days_for_allocation))+"_1.csv"), mode ='w') as csvfile:
		fieldName = ['class','wait','AllocatedSlotPreference']
		writer = csv.DictWriter(csvfile, fieldnames = fieldName)

		writer.writeheader()
		for i in range(len(urgentClassAllocatedSlotPreference)):
			writer.writerow({
				'class' : 0, # Urgent
				'wait' : waitUrgent[i],
				'AllocatedSlotPreference' : urgentClassAllocatedSlotPreference[i]
			})

		for i in range(len(mediumClassAllocatedSlotPreference)):
			writer.writerow({
				'class' : 1, # Medium
				'wait' : waitMedium[i],
				'AllocatedSlotPreference' : mediumClassAllocatedSlotPreference[i]
			})

		for i in range(len(notUrgentClassAllocatedSlotPreference)):
			writer.writerow({
				'class' : 2, # Not urgent
				'wait': waitNoturgent[i],
				'AllocatedSlotPreference' : notUrgentClassAllocatedSlotPreference[i]
			})

with open(os.path.join(os.getcwd(), "output/csv/slotCap_"+str(slot_cap)+"_days_"+str(len(days_for_allocation))+"_2.csv"), mode ='w') as csvfile:
		fieldName = ['Slot','IMPPreSS_population','Current_population','Non_allocated','final_allocations_conf_int','final_pref_allocations_conf_int','non_allocated_conf_int','non_allocated_std','final_allocations_std','final_pref_allocations_std']
		writer = csv.DictWriter(csvfile, fieldnames = fieldName)

		writer.writeheader()
		for i in range(len(x_axis2)):
			writer.writerow({
				'Slot': x_axis2[i],
				'IMPPreSS_population' : final_allocations_mean[i], 
				'Current_population' : final_pref_allocations_mean[i],
				'Non_allocated' : non_allocated_mean[i],
				'final_allocations_conf_int' : final_allocations_conf_int[i],
				'final_pref_allocations_conf_int' : final_pref_allocations_conf_int[i],
				'non_allocated_conf_int' : non_allocated_conf_int[i],
				'non_allocated_std' : non_allocated_std[i],
				'final_allocations_std' : final_allocations_std[i],
				'final_pref_allocations_std' : final_pref_allocations_std[i]
			})

ax1.bar(x_axis, plot_allocated_slot_pref, 
			yerr=plot_allocated_slot_pref_conf_int,
			width=0.4,
			alpha=0.4,
			color='b')

ax2.bar(x_axis, plot_delay, 
			yerr=plot_delay_conf_int,
			width=0.4,
			alpha=0.4,
			color='r')

fig.suptitle('Allocated Slot Preference and Delay vs importance')
ax1.set_ylabel('Allocated Slot Preference')
ax2.set_ylabel('Delay')
ax1.grid()
ax2.grid()
ax1.set_xlabel("Importance")
ax2.set_xlabel("Importance")
ax2.set_xticks(ticks=[0,1,2])
ax1.set_xticks(ticks=[0,1,2])
ax2.set_xticklabels(labels=['Urgent','Medium','Not Urgent'], fontsize=10)
ax1.set_xticklabels(labels=['Urgent','Medium','Not Urgent'], fontsize=10)
fig.savefig(os.path.join(os.getcwd(), "output/plots/slotCap_"+str(slot_cap)+"_days_"+str(len(days_for_allocation))+"_1.pdf"))

fig, ax = plt.subplots()
ax.bar(x_axis2 , final_allocations_mean,yerr=final_allocations_conf_int , color = 'gold',width=0.4,label ='VCG-T population')
ax.bar(x_axis2+0.4 , final_pref_allocations_mean , yerr= final_pref_allocations_conf_int , color = 'teal',width=0.4,label ='Current population')
ax.bar(x_axis2+0.8 , non_allocated_mean , yerr= non_allocated_conf_int , color = 'coral',width=0.4,label ='Non allocated')
plt.xlabel('Hourly slots of the day')
ax.set_ylabel('Population')
plt.xticks(x_axis2+0.2,x_axis2)
plt.tight_layout()
#ax.set_title("Population vs Slots ")
ax.hlines(slot_cap,xmin=7,xmax =len(M)+8,linestyle='dashed', color='red',label='Slot capacity',)
ax.grid()
ax.legend(loc='upper left')
fig.savefig(os.path.join(os.getcwd(), "output/plots/slotCap_"+str(slot_cap)+"_days_"+str(len(days_for_allocation))+"_2.pdf"))

# Clean the dir.
if os.path.exists("mark0.lp"):
	os.remove("mark0.lp")
