import pandas as pd
from datetime import datetime 

def data():
    data = pd.read_excel('./data.xls')
    points = data['7/1/2020  7:23:14 AM'].to_numpy()
    curr_date = "7/1/2020"
    timePoints = []
    temp = []
    for point in points:
        date = point.split(' ')[0]
        if date == curr_date:
            temp.append(point)
        else:
            timePoints.append(temp)
            temp=[]
            temp.append(point)
            curr_date=date
    timePoints.append(temp)
 
    for day in timePoints:
        day.sort(key = lambda date: datetime.strptime(date,"%m/%d/%Y %I:%M:%S %p"))

    final_arr=[[] for _ in range(31)]

    for k in range(len(timePoints)):
        slots=[]
        day=int(timePoints[k][0].split('/')[1])
        prevh=7
        prevm=0
        Pindex=0
        index=0
        for time in timePoints[k]:
            t=time.split(' ')[-2].split(':')
            h=int(t[0])
            m=int(t[1])
            if  (not prevh==h) or (prevm<30 and m>=30):
                Tmp=[timePoints[k][x+Pindex] for x in range(index-Pindex)]
                slots.append(Tmp)
                Pindex=index
            index = index + 1
            prevh = h
            prevm = m
        slots.append([timePoints[k][x+Pindex] for x in range(index-Pindex)])
        final_arr[day-1].extend(slots)

    Final =[]
    for k in final_arr:
        Temp = []
        for j in k:
            if(k.index(j) >=28): break
            Temp.append(len(j))
        Temp.extend([0] * (28 - len(Temp)))
        Final.append(Temp)
    
    return Final