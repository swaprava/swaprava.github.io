# social-distance-EUMAS21
This Repo. is for the simulation of the proposed MULTI_INDIV_ALLOC Aprox. algorithm.
