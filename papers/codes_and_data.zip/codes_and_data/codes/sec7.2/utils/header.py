#!/usr/bin/env python

from utils.config import *
from utils.windowSum import *
from multiprocessing import Pool
