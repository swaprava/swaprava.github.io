results_monday.xls
(median dataset)
Stata code: Final Do file

results_friday.xls
(TRUPEQA dataset)
Stata code: Final Do File trupeqa


The TRUPEQA dataset contains the 3 papers against each grader that are non-probe papers, the rest 2 papers assigned to them were probes and are used to calculated the TRUPEQA score and bonuses -- and are not shown in the dataset to keep it compact.

The simulation of appendix C is done using the code welfare_comparison_plot.py
